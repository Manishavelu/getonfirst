<!DOCTYPE html>
<html>
<head>
	<title>Get On First</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
<!--bootstrap cdn-->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!--bootstrap cdn ends-->
 <!--my styles-->
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/styles.css">
  <link rel="stylesheet" type="text/css" href="css/animate.css">

  <!--my styles end-->

  <!--menu js-->
   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
  <script src="js/script.js"></script>

  <!--google fonts-->
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Josefin+Sans" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Lora" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Cookie" rel="stylesheet">
<!--google font end-->

<!--wow js start-->
<script type="text/javascript" src="js/wow.min.js"></script>
<!--wow js end-->

 <!--font awesome start-->
  <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--font awesome end-->

 <!--clients silk slider-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
   <!--clients silk end-->

   <!--responsive css-->
   <link rel="stylesheet" type="text/css" href="css/responsive.css">

</head>
<!--wow animation start-->
<script>
  new WOW().init();
</script>
<!--wow animation end-->



<body>
<!--header start-->

<?php include('includes/header.php')?>
<!--header end-->

<!--First service start-->
<section id="service-section">
	<div class="row">
	<div class="col-sm-4 col-md-12 col-lg-4 wow fadeIn serviceHeading bg-white" data-wow-delay="200ms">
		<div class="breakContent"><h1>What <br>we<br> do<span>?</span></h1></div>
	</div>
	<div class="col-sm-4 col-md-6 col-lg-4 wow fadeIn serviceHeading-second" data-wow-delay="400ms">
		<div class="breakContent"><h2>Website Designing & Developing</h2></div>
		<div class="border1"></div>
		<p><i>We create super-rich experiences online!</i><br><br>
Getonfirst is a full-scale Digital Marketing Agency based out of New Delhi, India. We mix our years of experience and knowledge to create solutions for our clients which are not only performance driven, but also creative.  We are running kick-ass digital campaigns for our clients, even as you read this!</p>
<a href="website-designing.php">Read More..</a>
</div>
	<div class="col-sm-4 col-md-6 col-lg-4 wow fadeIn serviceHeading" data-wow-delay="600ms">
		<div class="mobileViewHeading"><h2>Digital Marketing</h2></div>
		<div class="border1"></div>
		<p><i>Marketing brands with care</i><br><br>
What is marketing if it is not performance driven?

We create digital experiences which stick with audiences and also reach the end objective. Trust us with making your brand visible and desired, with highly focused performance marketing.</p>
<a href="digital.php">Read More..</a>
	</div>
	</div>
</section>
<!--First service end-->

<!--Second service Section -->

<section id="servicesection1">
	<div class="row">
		<div class=" gap col-sm-6 col-md-6 col-xs-12 wow fadeIn" data-wow-delay="400ms" >
    <div class="hovereffect">
        <img class="img-responsive" src="images/web2.jpg" width="100%" alt="">
            <div class="overlay">
                
				<p>
					<a href="website-designing.php"><h2>Website Design, Development &  Digital marketing</h2></a>
				</p>
            </div>
    </div>
</div>
        <div class="col-sm-6 col-md-6 col-xs-12 gap">
        	<div class="row">
        <div class="col-sm-6 wow fadeIn gap" data-wow-delay="700ms"><div class="hovereffect">
      <img class="img-responsive" src="images/development.jpg" width="100%" alt="">
            <div class="overlay">
                
				<p>
					<a href="website-designing.php"><h2>Web <br>Development</h2>
					</a>
				</p>
            </div>
    </div></div>
         <div class="col-sm-6  col-md-6 wow fadeIn gap" data-wow-delay="700ms"><div class="hovereffect">
        <img class="img-responsive" src="images/smo.jpg" width="100%" alt="">
            <div class="overlay">
               
				<p>
					<a href="digital.php#smo"> <h2 class="text-white">Search Media Optimization</h2></a>
				</p>
            </div>
    </div></div>
         <div class="col-sm-6 col-md-6 wow fadeIn gap" data-wow-delay="700ms"><div class="hovereffect">
        <img class="img-responsive" src="images/smm.jpg" width="100%" alt="">
            <div class="overlay">
                
				<p>
					<a href="digital.php#ppc"><h2 class="text-white">pay per click</h2></a>
				</p>
            </div>
    </div></div>
        <div class="col-sm-6 col-md-6 wow fadeIn gap" data-wow-delay="700ms"><div class="hovereffect">
       <img class="img-responsive" src="images/seo.jpg" width="100%" alt="">
            <div class="overlay">
                
				<p>
					<a href="digital.php#seo"><h2 >SEO<br>
           (Local SEO)
          </h2></a>
				</p>
            </div>
    </div></div>
        
        
    </div>

        </div>
	</div>

</section>
<!--Second service end-->

<!--About start-->
<section id="section3">
	
	<div class="row">
		
		<div class="col-sm-6 bg-danger text-white gap getConnected">
      <div class="card innerConnect wow fadeIn" data-wow-delay="300ms" >
    
    <div class="card-body">
      <h1 class="card-title">About Us</h1>
      <div class="border1"></div>
     <p class="card-text"><i>Insights, Metrics and Analytics - Everything is connected!</i><br>
In a digital world where everything’s connected, we believe that the approach to digital communications has to be joined-up too. Our approach combines creativity & technology and blends a diverse range of digital marketing disciplines — from mobile and responsive web design to search and social media campaigns .</p>
      <a href="about.php" >Know  More..</a>
    </div>
  </div></div>

			
		<div class="col-sm-6 gap wow fadeIn" data-wow-delay="400ms">
			<img src="images/connected1.jpg" class="img-responsive" width="100%">
		</div>
	</div>

</section>
<!--About end-->


<!--innovative div start-->
<section id="section4">
	
	<div class="row">
		
		

		<div class="col-sm-6 gap wow fadeIn" data-wow-delay="400ms">
			<img src="images/creative.jpg" width="100%">
		</div>

		<div class="col-sm-6  text-white gap getConnected">
      <div class="card innerConnect wow fadeIn" data-wow-delay="300ms" >
    
    <div class="card-body">
      <h1 class="card-title">Creativity & Results!</h1>
      <div class="border1"></div>
    <p><i>Insights, Metrics and Analytics - Everything is connected!</i><br>
In a digital world where everything’s connected, we believe that the approach to digital communications has to be joined-up too. Our approach combines creativity & technology and blends a diverse range of digital marketing disciplines — from mobile and responsive web design to search and social media campaigns .we believe that the approach to digital communications.</p>
      <a href="about.php" >Know  More..</a>
    </div>
  </div></div>

		</div>
	</div>

</section>

<!--innovative div end-->

<!--clients start-->
<section id="clients">
  <h2>Our  Partners</h2>
   <div class="container customer-logos slider">
      <div class="slide"><img src="images/logo1.jpg"></div>
      
      <div class="slide"><img src="images/logo2.jpg"></div>
      <div class="slide"><img src="images/logo3.jpg"></div>
      <div class="slide"><img src="images/logo4.jpg"></div>
      <div class="slide"><img src="images/logo5.jpg"></div>
      <div class="slide"><img src="images/logo6.jpg"></div>
      <div class="slide"><img src="images/logo7.jpg"></div>
      <div class="slide"><img src="images/logo4.jpg"></div>
   </div>
</section>
<!--clients end-->

<!--Portfolio start-->
<section id="portfolio">
<div class="container">
	<div class="contentsPortfolio">
		<h1 class="text-center wow fadeIn" data-wow-delay="300ms">Want To Check Our Portfolio?</h1>

		<div class="checkNow text-center wow fadeIn" data-wow-delay="600ms" ><input type="button" class="btn2"  name="" value="Check Now"></div>
</div>
</section>
<!--Portfolio end-->


<!--footer part-->
<?php include('includes/footer.php')?>
<!--footer end-->


<!--client script-->
	<script type="text/javascript">
		
		$(document).ready(function(){
    $('.customer-logos').slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1500,
        arrows: false,
        dots: false,
        pauseOnHover: false,
        responsive: [{
            breakpoint: 768,
            settings: {
                slidesToShow: 4
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 3
            }
        }]
    });
});
	</script>
	<!--client script end-->
	
</body>
</html>