<!DOCTYPE html>
<html>
<head>
	<title>Get On First</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
<!--bootstrap cdn-->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!--bootstrap cdn ends-->
 <!--my styles-->
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/styles.css">
  <link rel="stylesheet" type="text/css" href="css/animate.css">
  <!--my styles end-->

  <!--google fonts-->
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Josefin+Sans" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Lora" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Cookie" rel="stylesheet">
<!--google font end-->

<!--wow js start-->
<script type="text/javascript" src="js/wow.min.js"></script>
<!--wow js end-->

<!--menu js-->
   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
  <script src="js/script.js"></script>

 <!--font awesome start-->
  <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>
  <!--font awesome end-->
  
 <!--clients silk slider-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
   <!--clients silk end-->

     <!--responsive css-->
   <link rel="stylesheet" type="text/css" href="css/responsive.css">

</head>
<!--wow animation start-->
<script>
  new WOW().init();
</script>
<!--wow animation end-->
<body>
<!--header start-->
<?php include('includes/header1.php')?>
<!--header end-->

<!--banner-->

<!--banner end-->


<!--All Service Section start-->

<section id="web-design">
	<div class="container headingAll">
	<div class="row">
		<div class="col-sm-6 wow fadeIn" data-wow-delay="300ms">
			<h3>Digital Marketing</h3>
			<div class="border1"></div>
			<p>In this fast evolving Internet age, the right Digital Marketing solutions from the best Digital Marketing Company in Delhi NCR can facilitate a powerful connect between your potential customers and your brand, ultimately leading to an improved brand recall. Get On First, as a leading Digital Marketing Company in India, helps you establish a foothold on the online medium for Search Engines and Social Media. At Get On First, we use ethical and proven methods to get your brand acquire and sustain a remarkable online presence.</p>
		</div>
		<div class="col-sm-6 wow fadeInRight digitalImg" data-wow-delay="700ms">

			<img src="images/digital2.png" width="100%" >
			
		</div>
	</div>
	</div>
	</section>

	<section>
    <div class=" contentsDesigning bg-info">
    	<div class="container ">
    	<h2 class="text-center text-white text-uppercase wow fadeIn" data-wow-delay="200ms">We connect brands with desirable digital audiences</h2>
    	<p class="wow fadeIn" data-wow-delay="400ms">In this fast evolving Internet age, the right Digital Marketing solutions from the best Digital Marketing Company in Delhi NCR can facilitate a powerful connect between your potential customers and your brand, ultimately leading to an improved brand recall. At Get On First, we use ethical and proven methods to get your brand acquire and sustain a remarkable online presence</p>
    </div></div>
</section>

<section id="seo">
	<div class="container headingAll">
	<div class="row">
		<div class="col-sm-6 wow fadeIn"  data-wow-delay="300ms">
			<h3>Search Engine Optimization</h3>
			<div class="border1"></div>
			<p>In this fast evolving Internet age, the right Digital Marketing solutions from the best Digital Marketing Company in Delhi NCR can facilitate a powerful connect between your potential customers and your brand, ultimately leading to an improved brand recall. .</p>
		</div>
		<div class="col-sm-6 wow fadeInRight" data-wow-delay="700ms">

			<img src="images/seo4.png" width="100%" >
			
		</div>
	</div>
	</div>
	</section>


	<section id="smo">
	<div class="container headingAll">
	<div class="row">
		
		<div class="col-sm-6 wow fadeInLeft" data-wow-delay="700ms">

			<img src="images/smo.png" width="100%" >
			
		</div>
		<div class="col-sm-6 wow fadeIn" data-wow-delay="300ms">
			<h3>Social Media Optimization</h3>
			<div class="border1"></div>
			<p>In this fast evolving Internet age, the right Digital Marketing solutions from the best Digital Marketing Company in Delhi NCR can facilitate a powerful connect between your potential customers and your brand, ultimately leading to an improved brand recall. </p>
		</div>
	</div>
	</div>
	</section>


	<section id="smm">
	<div class="container headingAll">
	<div class="row">
		<div class="col-sm-6 wow fadeIn" data-wow-delay="300ms">
			<h3>Social Media Marketing</h3>
			<div class="border1"></div>
			<p>In this fast evolving Internet age, the right Digital Marketing solutions from the best Digital Marketing Company in Delhi NCR can facilitate a powerful connect between your potential customers and your brand, ultimately leading to an improved brand recall. .</p>
		</div>
		<div class="col-sm-6 wow fadeInRight" data-wow-delay="700ms">

			<img src="images/smm1.png" width="100%" >
			
		</div>
	</div>
	</div>
	</section>


	<section id="marketing">
	<div class="container headingAll">
	<div class="row">
		<div class="col-sm-5 wow fadeInLeft" data-wow-delay="700ms">

			<img src="images/content-marketing.png" width="100%" >
			
		</div>
		<div class="col-sm-1"></div>
		<div class="col-sm-6 wow fadeIn " data-wow-delay="300ms">
			<h3>Content Marketing</h3>
			<div class="border1"></div>
			<p>In this fast evolving Internet age, the right Digital Marketing solutions from the best Digital Marketing Company in Delhi NCR can facilitate a powerful connect between your potential customers and your brand, ultimately leading to an improved brand recall. .</p>
		</div>
		
	</div>
	</div>
	</section>


	<section id="ppc">
	<div class="container headingAll">
	<div class="row">
		
		
		<div class="col-sm-6 wow fadeIn" data-wow-delay="300ms">
			<h3>Pay Per Click</h3>
			<div class="border1"></div>
			<p>In this fast evolving Internet age, the right Digital Marketing solutions from the best Digital Marketing Company in Delhi NCR can facilitate a powerful connect between your potential customers and your brand, ultimately leading to an improved brand recall. .</p>
		</div>
		<div class="col-sm-1"></div>

		<div class="col-sm-5 wow fadeInRight" data-wow-delay="700ms">

			<img src="images/ppc1.png" width="100%" >
			
		</div>
		
	</div>
	</div>
	</section>




	<section id="designDevelopservice">
<div class="container">
	<div class="row">
		<div class="col-sm-3 serviceInner wow fadeIn"  data-wow-delay="200ms">
			<img src="images/icon2.png">
			<h4>Creative Strategy</h4>
			<p class="text-center">Ideas that deliver ROI</p>
		</div>
		<div class="col-sm-3 serviceInner wow fadeIn" data-wow-delay="400ms">
			<img src="images/team.png">
			<h4>Experienced Team</h4>
			<p class="text-center">Reliable and Responsible People </p>
		</div>
		<div class="col-sm-3 serviceInner wow fadeIn" data-wow-delay="600ms">
			<img src="images/result.png">
			<h4>Results</h4>
			<p class="text-center">Amazing Analytics & Reports </p>
		</div>
		<div class="col-sm-3 serviceInner wow fadeIn" data-wow-delay="800ms">
			<img src="images/Strategy.png">
			<h4>Strategic Control</h4>
			<p class="text-center">Conversion Optimization</p>
		</div>
		
	</div>
</div>
	

</section>







<!--footer part-->
<?php include('includes/footer.php')?>
<!--footer end-->



	
</body>
</html>