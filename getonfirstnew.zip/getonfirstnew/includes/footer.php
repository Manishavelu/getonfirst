<section id="footer">
	<div class="container">
		<div class="row">
		<div class="col-sm-3 innerFoot wow fadeIn" data-wow-delay="300ms"><h3>About</h3><div class="border2"></div>
        <p>In a digital world where everything’s connected, we believe that the approach to digital communications has to be joined-up too. Our approach combines creativity & technology and blends a diverse range of digital marketing disciplines </p>
	</div>
		<div class="col-sm-3 innerFoot wow fadeIn" data-wow-delay="500ms"><h3>Quicklinks</h3><div class="border2"></div><br>
    
      	<li>Services</li>
      	<li>Portfolio</li>
      	<li>Location Map</li>
      
	</div>
		<div class="col-sm-3 innerFoot wow fadeIn" data-wow-delay="700ms"><h3>Reach Us</h3><div class="border2"></div>
<p>
3/12 Outer ring road
Marathali, Bangalore
Email:getonfirst@gmail.com
Phone:+91 2347849879</p>
	</div>
		<div class="col-sm-3 innerFoot wow fadeIn" data-wow-delay="900ms"><h3>Follow Us</h3><div class="border2"></div>
<div class="social">
	<i class='fab fa-facebook-f'></i>
	<i class='fab fa-twitter'></i>
	<i class='fab fa-google-plus-g'></i>
	<i class='fab fa-linkedin-in'></i>
</div>
	</div>
		</div>
	</div>

</section>